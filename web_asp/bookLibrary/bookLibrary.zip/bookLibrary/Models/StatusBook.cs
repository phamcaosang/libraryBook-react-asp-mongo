﻿namespace BookLibrary.Models
{
    public enum StatusBook
    {
        Available,
        SoldOut
    }
}
