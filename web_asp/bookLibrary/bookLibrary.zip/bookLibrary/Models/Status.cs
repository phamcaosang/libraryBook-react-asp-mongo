﻿namespace BookLibrary.Models
{
    public enum Status
    {
        Pending,
        Accepted,
        Refused,
        Expired,
        /*Returned*/
        Done
    }
}
