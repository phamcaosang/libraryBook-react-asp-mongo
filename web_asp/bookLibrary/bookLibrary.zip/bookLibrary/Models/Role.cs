﻿namespace BookLibrary.Models
{
    public enum Role
    {
        Admin,
        User
    }
}
